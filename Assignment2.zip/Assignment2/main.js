let main_div = document.querySelector('.image-box')
let btn = document.querySelector('.btn')

btn.addEventListener('click', ()=>{
fetch('https://jsonplaceholder.typicode.com/photos?_limit=100')
.then((resp)=>resp.json()
).then((result)=>{
    result.map((value)=>{
        let key = value.url;
        let imgTag = document.createElement('img');
        (imgTag.src = `https://picsum.photos/140/240?random=${key}`)
        main_div.appendChild(imgTag)
    })
})
})